namespace CounterFunctions
{
    internal class ConnectionRequest
    {
        public string DeviceId { get; set; }
        public string UserId { get; set; }
    }
}